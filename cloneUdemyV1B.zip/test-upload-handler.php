<?php
// Handler simple para test de upload
require_once 'config/database.php';
require_once 'config/config.php';

echo "<h1>Resultado del Test de Upload</h1>";

echo "<h2>Datos POST recibidos:</h2>";
echo "<pre>";
print_r($_POST);
echo "</pre>";

echo "<h2>Archivos recibidos:</h2>";
echo "<pre>";
print_r($_FILES);
echo "</pre>";

if (isset($_FILES['videos'])) {
    echo "<h2>Análisis de archivos:</h2>";
    
    if (is_array($_FILES['videos']['name'])) {
        $fileCount = count($_FILES['videos']['name']);
        echo "Número de archivos: " . $fileCount . "<br>";
        
        for ($i = 0; $i < $fileCount; $i++) {
            echo "<h3>Archivo " . ($i + 1) . ":</h3>";
            echo "Nombre: " . $_FILES['videos']['name'][$i] . "<br>";
            echo "Tipo: " . $_FILES['videos']['type'][$i] . "<br>";
            echo "Tamaño: " . formatBytes($_FILES['videos']['size'][$i]) . "<br>";
            echo "Error: " . $_FILES['videos']['error'][$i] . "<br>";
            echo "Archivo temporal: " . $_FILES['videos']['tmp_name'][$i] . "<br>";
            echo "¿Existe archivo temporal?: " . (file_exists($_FILES['videos']['tmp_name'][$i]) ? 'Sí' : 'No') . "<br>";
            
            // Verificar tipo
            if (validateFileType($_FILES['videos']['name'][$i], ALLOWED_VIDEO_TYPES)) {
                echo "✅ Tipo de archivo válido<br>";
            } else {
                echo "❌ Tipo de archivo no válido<br>";
            }
            
            // Verificar tamaño
            if ($_FILES['videos']['size'][$i] <= MAX_VIDEO_SIZE) {
                echo "✅ Tamaño válido<br>";
            } else {
                echo "❌ Archivo demasiado grande<br>";
            }
            
            echo "<br>";
        }
    } else {
        echo "❌ Los archivos no están en formato array<br>";
    }
} else {
    echo "❌ No se recibieron archivos en el campo 'videos'<br>";
}

echo "<h2>Test de API:</h2>";
echo "Ahora vamos a probar la API real...<br>";

if (isset($_POST['curso_id']) && isset($_POST['seccion_id']) && isset($_FILES['videos'])) {
    // Crear FormData simulado para la API
    $postData = [
        'curso_id' => $_POST['curso_id'],
        'seccion_id' => $_POST['seccion_id']
    ];
    
    echo "Datos que se enviarían a la API:<br>";
    echo "curso_id: " . $postData['curso_id'] . "<br>";
    echo "seccion_id: " . $postData['seccion_id'] . "<br>";
    echo "videos: " . count($_FILES['videos']['name']) . " archivo(s)<br>";
    
    echo "<br><strong>Para continuar con la prueba real, usa el formulario de upload en la aplicación.</strong><br>";
}

echo "<br><a href='test-upload.php'>Volver al test</a>";
echo "<br><a href='index.php'>Volver al Dashboard</a>";

?>

<style>
body { font-family: Arial, sans-serif; margin: 20px; }
h1, h2, h3 { color: #333; }
pre { background: #f5f5f5; padding: 10px; border-radius: 5px; overflow-x: auto; }
</style>
